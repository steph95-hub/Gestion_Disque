package com.disquesGestion;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Disque {
  
	private String titre;
	List<String> morceaux = new ArrayList<String>();
	private Date dateSortie;
	private Personne personne;
	
	public Disque() {
		super();
	}

	public Disque(String titre, List<String> morceaux, Date dateSortie) {
		super();
		this.titre = titre;
		this.morceaux = morceaux;
		this.dateSortie = dateSortie;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public List<String> getMorceaux() {
		return morceaux;
	}

	public void setMorceaux(List<String> morceaux) {
		this.morceaux = morceaux;
	}

	public Date getDateSortie() {
		return dateSortie;
	}

	public void setDateSortie(Date dateSortie) {
		this.dateSortie = dateSortie;
	}

	public Personne getPersonne() {
		return personne;
	}

	public void setPersonne(Personne personne) {
		this.personne = personne;
	}
	/*m�thode pour simuler l'affichage des disques */
	public String afficheDisque(List<Disque> disque) {
		int i;
		String infoDisque=" ";
		for(i=0;i<disque.size();i++) {
		  infoDisque += "Le disque numero "+(i+1)+" est titr� "+disque.get(i).titre+", et comporte "+disque.get(i).morceaux.size()+ " morceaux et est sortie "+disque.get(i).dateSortie+" ";
	    }
		return infoDisque;

	}
}
