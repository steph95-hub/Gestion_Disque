package com.disquesGestion;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Personne {
private String nom;
private String prenom;
private Date date_Naissance;
private Date date_Deces;
private Role role = new Role();
private List<Disque>disque =new ArrayList<Disque>();

public Role getRole() {
	return role;
}

public void setRole(Role role) {
	this.role = role;
}

public Personne() {
	
}

public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getPrenom() {
	return prenom;
}
public void setPrenom(String prenom) {
	this.prenom = prenom;
}
public Date getDate_Naissance() {
	return date_Naissance;
}
public void setDate_Naissance(Date date_Naissance) {
	this.date_Naissance = date_Naissance;
}
public Date getDate_Deces() {
	return date_Deces;
}
public void setDate_Deces(Date date_Deces) {
	this.date_Deces = date_Deces;
}



public List<Disque> getDisque() {
	return disque;
}

public void setDisque(List<Disque> disque) {
	this.disque = disque;
}


/*m�thode pour tester l'affichage des personnes*/
public String affiche(Personne personne) {
	Disque disque1 = new Disque();
	String info = "L'artiste s'appelle "+personne.getNom()+" "+personne.getPrenom()+". Il est n�e le " +personne.getDate_Naissance()+", et est d�c�d� le "+personne.getDate_Deces()+
			". "+personne.getRole().afficheRole(role)+" L'artiste a � son actif "+personne.getDisque().size()+" Disque(s) ."+disque1.afficheDisque(personne.getDisque());
	return info;
}






}
