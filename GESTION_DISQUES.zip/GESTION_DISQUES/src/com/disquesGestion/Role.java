package com.disquesGestion;

import java.util.ArrayList;
import java.util.List;

public class Role {
	
	private boolean musicien;
	private boolean producteur;
	private boolean compositeur;
	private List<Personne> personne = new ArrayList<Personne>();
	
	public Role() {
		super();
	}

	public Role(boolean musicien, boolean producteur, boolean compositeur) {
		super();
		this.musicien = musicien;
		this.producteur = producteur;
		this.compositeur = compositeur;
	}

	public boolean isMusicien() {
		return musicien;
	}

	public void setMusicien(boolean musicien) {
		this.musicien = musicien;
	}

	public boolean isProducteur() {
		return producteur;
	}

	public void setProducteur(boolean producteur) {
		this.producteur = producteur;
	}

	public boolean isCompositeur() {
		return compositeur;
	}

	public void setCompositeur(boolean compositeur) {
		this.compositeur = compositeur;
	}

	public List<Personne> getPersonne() {
		return personne;
	}

	public void setPersonne(List<Personne> personne) {
		this.personne = personne;
	}
	/*m�thode pour simuler l'affichage des roles */
	public String afficheRole(Role role) {
		String roleInfo;
		if(role.musicien && role.compositeur && role.producteur) {
			roleInfo = "L'artiste est un musicien,un compositeur et un producteur";
			return roleInfo;
		}
		
		else if(role.musicien && role.compositeur && !role.producteur) {
			roleInfo = "L'artiste est un musicien et un compositeur";
			return roleInfo;
		}
		
		else if(role.musicien && !role.compositeur && role.producteur) {
			roleInfo = "L'artiste est un musicien et un producteur";
			return roleInfo;
		}
		
		else if(!role.musicien && role.compositeur && role.producteur) {
			roleInfo = "L'artiste est un compositeur et un producteur";
			return roleInfo;
		}
		
		else if(role.musicien && !role.compositeur && !role.producteur) {
			roleInfo = "L'artiste est un musicien";
			return roleInfo;
		}
		
		else if(!role.musicien && role.compositeur && !role.producteur) {
			roleInfo = "L'artiste est un compositeur";
			return roleInfo;
		}
		
		else{
			roleInfo = "L'artiste est un producteur";
			return roleInfo;
		}
		
	}
	
	
	

}
