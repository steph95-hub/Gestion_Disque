package com.disquesGestion.main;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import com.disquesGestion.*;

public class Gestion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Disque>  disque = new ArrayList<Disque>(); 
		Disque disque1 = new Disque();
		disque1.setTitre("Premier Titre");
		List<String> morceau1 = new ArrayList<String>();
		
		morceau1.add("Morceau 1");
		morceau1.add("Morceau 2");
		
		disque1.setMorceaux(morceau1);
		disque1.setDateSortie(new Date());
		
		Disque disque2 = new Disque();
		disque2.setTitre("Deuxi�me Titre");
		ArrayList<String>morceau2 = new ArrayList<String>();
		morceau2.add("Morceau2 1");
		morceau2.add("Morceau2 2");
		morceau2.add("Morceau2 3");
		disque2.setMorceaux(morceau2);
		disque2.setDateSortie(new Date());
		
		disque.add(disque1);
		disque.add(disque2);
		
		Role role = new Role();
		role.setMusicien(true);
		role.setProducteur(true);
		role.setCompositeur(false);
		
		
		Personne personne = new Personne();
		personne.setNom("Houan");
		personne.setPrenom("Ange Didier");
		personne.setDate_Naissance(new Date());
		personne.setDate_Deces(new Date());  
		personne.setRole(role);
		personne.setDisque(disque);
		
		System.out.println(personne.affiche(personne));
		
		
		
		
	}
	
	

}
